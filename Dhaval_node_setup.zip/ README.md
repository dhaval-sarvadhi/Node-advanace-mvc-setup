# Node.js Sequelize PostgreSQL MVC Setup

## Author
**Dhaval Patel**

## Project Structure
- MVC Architecture
- Sequelize ORM with PostgreSQL
- Written in TypeScript

## Tech Stack
- Node.js
- Express.js
- Sequelize ORM
- PostgreSQL
- TypeScript
