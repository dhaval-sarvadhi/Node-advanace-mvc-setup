export const FILENAME = 'logs/%DATE%-results.log';

export enum DATE_FORMATE {
    TIMESTAMP = 'YYYY-MM-DD HH:mm:ss',
    DATE_PATTERN = 'YYYY-MM-DD'
};
