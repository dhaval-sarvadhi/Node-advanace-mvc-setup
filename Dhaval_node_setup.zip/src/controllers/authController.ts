/**
 * @file user.controller.ts
 * @description Controller for managing user-related routes and logic.
 * @author
 * Dhaval Patel
 * @created 2025-05-29
 */

import { NextFunction, Request, Response } from "express";
import { ErrorController } from "../core/ErrorController";
import { SuccessResponse } from '../core/ApiResponse';
import { BadRequestError, ApiError } from '../core/ApiError';

const EC = new ErrorController();

export class AuthController {

  public async login(req: Request, res: Response, next: NextFunction) {
    try {
      new SuccessResponse(EC.errorMessage(EC.success), {}).send(res);
    }
    catch (e: any) {
      ApiError.handle(new BadRequestError(e.message), res);
    }
  }

}
